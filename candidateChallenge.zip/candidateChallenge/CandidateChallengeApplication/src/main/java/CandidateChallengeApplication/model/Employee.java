package CandidateChallengeApplication.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;


@Entity
@Table(name = "employee")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	
	@NotBlank
	@Size(max = 20)
	private long id;
	

	//@NotBlank
	@Size(max = 20)
	private Long supervisor_id;
	
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Long getSupervisor_id() {
		return supervisor_id;
	}

	public void setSupervisor_id(Long supervisor_id) {
		this.supervisor_id = supervisor_id;
	}

	public Employee() {
	}
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", supervisor_id=" + supervisor_id +  "]";
	}


	
	
}
