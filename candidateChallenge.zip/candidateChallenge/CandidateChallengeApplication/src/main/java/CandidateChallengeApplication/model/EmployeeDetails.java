package CandidateChallengeApplication.model;


import java.util.Set;

import org.springframework.stereotype.Component;

@Component
public class EmployeeDetails {
	
	private Employee employee;


	private Set<Property> property;

	public Employee getEmployee() {
	return employee;
	}

	public void setEmployee(Employee employee) {
	this.employee = employee;
	}

	public Set<Property> getProperty() {
		return property;
	}

	public void setProperty(Set<Property> propertyList2) {
	this.property = propertyList2;
	}
		
	}
