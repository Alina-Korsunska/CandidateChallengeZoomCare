package CandidateChallengeApplication.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
@Table(name = "property")
public class Property {
	@Id
	@NotBlank
	@Size(max = 20)
	@Column(name = "employee_id")
	private long employee_id;
	
	@NotBlank
	@Size(max = 256)
	@Column(name = "key")
	private String key;
	
	@NotBlank
	@Size(max = 256)
	@Column(name = "value")
	private String value;
	


	public long getEmployee_id() {
		return employee_id;
	}


	public void setEmployee_id(long employee_id) {
		this.employee_id = employee_id;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	@Override
	public String toString() {
		return "Properties [employee_id=" + employee_id + ", key=" + key + ", value=" + value 
				+ "]";
	}
	
}
