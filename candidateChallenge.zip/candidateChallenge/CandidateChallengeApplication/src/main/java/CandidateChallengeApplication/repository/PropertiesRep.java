package CandidateChallengeApplication.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import CandidateChallengeApplication.model.Property;

	
@Repository
public interface PropertiesRep extends JpaRepository<Property, Long> {
	

	@Query("SELECT p.value FROM Property p WHERE p.employee_id = :employee_id and p.key = :key")
    public String findByKey(@Param("employee_id") Long employee_id,@Param("key")String key);
    
   @Query("SELECT p FROM Property p WHERE p.employee_id = :employee_id")
    public List<Property> find(@Param("employee_id") Long employee_id);
	
	


}

	


		

