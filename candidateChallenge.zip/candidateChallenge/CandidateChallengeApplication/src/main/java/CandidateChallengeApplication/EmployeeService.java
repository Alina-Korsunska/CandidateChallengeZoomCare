package CandidateChallengeApplication;

import java.util.ArrayList;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import CandidateChallengeApplication.model.Employee;
import CandidateChallengeApplication.model.EmployeeDetails;
import CandidateChallengeApplication.model.Property;
import CandidateChallengeApplication.repository.EmployeeRepository;
import CandidateChallengeApplication.repository.PropertiesRep;

@Service
public class EmployeeService {

	@Autowired
	EmployeeRepository rep;

	@Autowired
	PropertiesRep rep2;


	//fetch all emp details and properties by empid
	public EmployeeDetails getEmployeeById(long id)
	{	
		EmployeeDetails details= new EmployeeDetails();
		Employee emp = null;
		try {
			Optional<Employee> op = rep.findById(id);
			
			if (op.isPresent()) {
				emp = op.get();
			}

			details.setEmployee(emp);
		}catch(Exception e)
		{

		}
		if(emp==null) {
			Employee emp1 = new Employee();
			emp1.setId(id);
			details.setEmployee(emp1);
		}
		
		Set<Property> propertyList2= new LinkedHashSet<Property>();
		List<Property> property = (List<Property>) rep2.find(id);
		String k = "title";	
		String value = rep2.findByKey(id,k);
		if(k!=null) {
			Property p = new Property();
			p.setEmployee_id(id);
			p.setKey(k);
			p.setValue(value);
			propertyList2.add(p);	
	}
		propertyList2.addAll(property);
		
		details.setProperty(propertyList2);
		return details;

	}
	

	// fetch employees and properties
		public List<EmployeeDetails> getAllEmployee() {
			long c=rep.count();
			List<EmployeeDetails> detailsList= new ArrayList<EmployeeDetails>();
			for(int i=0;i<c;i++) {
				EmployeeDetails details1=new EmployeeDetails();
				details1=getEmployeeById(i+1);
				detailsList.add(details1);

			}
			return detailsList;
		}
}
