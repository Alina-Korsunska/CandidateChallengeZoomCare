package CandidateChallengeApplication;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import CandidateChallengeApplication.model.EmployeeDetails;

@RestController
@RequestMapping(value = "/employee")
public class Controller {
	@Autowired
	EmployeeService service;


	@GetMapping(path = "/find/{id}", produces = "application/json")
	public EmployeeDetails findEmployeeById(@PathVariable("id") long id) {
		return service.getEmployeeById(id);

	}

	@GetMapping(value="/find/all", produces ="application/json")
	public List<EmployeeDetails> getAllTopEmpl() {
	return service.getAllEmployee();
	}
}
